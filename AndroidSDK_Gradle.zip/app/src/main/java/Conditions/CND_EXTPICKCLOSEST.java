/* Copyright (c) 1996-2022 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
// ------------------------------------------------------------------------------
// 
// PICK CLOSEST OBJECT
// 
// ------------------------------------------------------------------------------
package Conditions;

import Objects.CObject;
import RunLoop.CRun;
import RunLoop.CObjInfo;
import Params.PARAM_OBJECT;
import Events.CQualToOiList;
import java.util.ArrayList;

public class CND_EXTPICKCLOSEST extends CCnd
{    
    public boolean eva1(CRun rhPtr, CObject hoPtr)
    {
		return eva2(rhPtr);
    }
    public boolean eva2(CRun rhPtr)
    {
        CObject pHo = rhPtr.rhEvtProg.evt_FirstObject(evtOiList);
        if (pHo == null)
            return false;
        int cpt = rhPtr.rhEvtProg.evtNSelectedObjects;

        short oi = ((PARAM_OBJECT)evtParams[0]).oi;
		short[] oi2List;
        if (oi >= 0) {
			oi2List = oiOneObjectList;
			oi2List[0] = oi;
			oi2List[1] = ((PARAM_OBJECT) evtParams[0]).oiList;
        }
        else {
            CQualToOiList qoil = rhPtr.rhEvtProg.qualToOiList[((PARAM_OBJECT) evtParams[0]).oiList & 0x7FFF];
            oi2List = qoil.qoiList;
        }

        // For each object 1
        double minDistance = 0;
		ArrayList<CObject> hoList = new ArrayList<CObject>();
        do {
            // Check if it's closer from object(s) 2 than previous objects 1
            int nOi = 0;
            for (nOi = 0; nOi < oi2List.length; nOi += 2)
            {
                CObjInfo poil = rhPtr.rhOiList[oi2List[nOi + 1]];

                // Already selected in event?
                if (poil.oilEventCount == rhPtr.rhEvtProg.rh2EventCount)
                {
                    // Explore selected object list
                    short num = poil.oilListSelected;
                    while (num >= 0)
                    {
                        CObject pHo2 = rhPtr.rhObjectList[num];
                        if (pHo2 == null)
                            break;
                        if ((pHo2.hoFlags & CObject.HOF_DESTROYED) == 0) {
                            double distance = (pHo2.hoX - pHo.hoX) * (pHo2.hoX - pHo.hoX) + (pHo2.hoY - pHo.hoY) * (pHo2.hoY - pHo.hoY);
                            if (hoList.size() == 0) {
                                minDistance = distance;
                                hoList.add(pHo);
                            }
                            else if (distance <= minDistance) {
                                if (distance == minDistance)
                                    hoList.add(pHo);
                                else {
                                    minDistance = distance;
                                    hoList.clear();
                                    hoList.add(pHo);
                                }
                            }
                        }
                        num = pHo2.hoNextSelected;
                    }
                }

                // Not selected => take full list
                else {
                    if (poil.oilNObjects != 0) {
                        short nObl = poil.oilObject;

                        do {
                            CObject pHo2 = rhPtr.rhObjectList[nObl];
                            if (pHo2 == null)
                                break;
                            if ((pHo2.hoFlags & CObject.HOF_DESTROYED) == 0) {
                                double distance = (pHo2.hoX - pHo.hoX) * (pHo2.hoX - pHo.hoX) + (pHo2.hoY - pHo.hoY) * (pHo2.hoY - pHo.hoY);
								if (hoList.size() == 0) {
									minDistance = distance;
									hoList.add(pHo);
								}
								else if (distance <= minDistance) {
									if (distance == minDistance)
										hoList.add(pHo);
									else {
										minDistance = distance;
										hoList.clear();
										hoList.add(pHo);
									}
								}
                            }

                            nObl = pHo2.hoNumNext;
                        } while (nObl >= 0);
                    }
                }
            }

            // Next object 1
            pHo = rhPtr.rhEvtProg.evt_NextObject();

        } while (pHo != null);

        if (hoList.size() == 0)
            return false;

		if (hoList.size() == 1)
            rhPtr.rhEvtProg.evt_ForceOneObject(evtOiList, hoList.get(0));
        else
            rhPtr.rhEvtProg.evt_SelectObjects(evtOiList, hoList);

		return true;
    }
}
