/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
// ------------------------------------------------------------------------------
// 
// COMPARE TO FIXED VALUE
// 
// ------------------------------------------------------------------------------
package Conditions;

import Events.CEvent;
import Objects.CObject;
import Params.CParamExpression;
import RunLoop.CObjInfo;
import RunLoop.CRun;

public class CND_EXTCMPVARFIXED extends CCnd implements IEvaExpObject
{
    public boolean eva1(CRun rhPtr, CObject hoPtr)
    {
        // Possible object conflict between condition and expression?
        //if ((evtFlags2 & CEvent.EVFLAG2_NOOBJECTINTERDEPENDENCE) == 0)
			return evaExpObject(rhPtr, this);

		// For some reason this code doesn't work in some cases... need to find why...
/*
        CParamExpression p = (CParamExpression) evtParams[0];
		if (p.comparaison != 0)	// COMPARE_EQ
			return evaExpObject(rhPtr, this);

        // No object conflict between condition and expression => get fixed value from expression parameter and directly get unique object
        int fixedValue;
        if ( p.tokens.length == 2 && p.tokens[0].isNumericalConstant() ) {
            fixedValue = p.tokens[0].getInt();
		}
        else {
            fixedValue = rhPtr.get_EventExpressionInt(p);
        }

        // Does the fixed value correspond to an existing object?
        int honum = (fixedValue & 0xFFFF);
        CObject pHo = null;
		if (honum < rhPtr.rhObjectList.length)
			pHo = rhPtr.rhObjectList[honum];
        if (pHo == null || pHo.hoCreationId != ((fixedValue >>> 16) & 0xFFFF)) {
            rhPtr.rhEvtProg.evt_DeselectObject(evtOiList);
            return false;
        }

        // Verify CObjInfo is identical
        if (pHo.hoOiList.oilIndex != evtOiList)
	    {
            // Nope, is evtOiList a qualifier?
            boolean oilOK = false;
            if (evtOiList < 0)
            {
                // Yes, check if pHo has this qualifier
                short q =  (short)(evtOiList & 0x7FFF);
                if (pHo.hoOiList.oilRealQualifiers != null) {
                    for (short qo : pHo.hoOiList.oilRealQualifiers) {
                        if (qo == q) {
                            oilOK = true;
                            break;      // object has this qualifier
                        }
                    }
                }
            }
            if (!oilOK) {
                rhPtr.rhEvtProg.evt_DeselectObject(evtOiList);
                return false;
            }
    }

        // Verify if object is selected
        CObjInfo oilPtr = pHo.hoOiList;
        if (oilPtr.oilEventCount == rhPtr.rhEvtProg.rh2EventCount)
		{
            // CObjInfo partially selected => check if the object is in the selection list
            boolean isSelected = false;
            short ois = oilPtr.oilListSelected;
            if (ois >= 0) {
                CObject pHo1;
                do {
                    if (pHo.hoNumber == ois) {
                        isSelected = true;
                        break;                          // object is selected
                    }
                    pHo1 = rhPtr.rhObjectList[ois];
                    if (pHo1 == null)
                        break;
                    ois = pHo1.hoNextSelected;
                } while (ois >= 0);
            }
            if (!isSelected) {
                rhPtr.rhEvtProg.evt_DeselectObject(evtOiList);
                return false;   // object not found in selection list for this CObjInfo
            }
        }
        //else ; // CObjInfo fully selected => object is selected
        //

        // Yes => select unique object
        rhPtr.rhEvtProg.evt_ForceOneObject(evtOiList, pHo);
        return true;
*/
    }
    public boolean eva2(CRun rhPtr) {
        //return eva1(rhPtr, null);
		return evaExpObject(rhPtr, this);
    }
    public boolean evaExpRoutine(CObject hoPtr, int value, short comp) {
        int fixed = (hoPtr.hoCreationId << 16) | (((int) hoPtr.hoNumber) & 0xFFFF);
        return CRun.compareTer(fixed, value, comp);
    }
}

