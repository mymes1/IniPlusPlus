/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

package Actions;

import Expressions.CValue;
import Objects.CObject;
import OpenGL.GLRenderer;
import Params.CParamExpression;
import RunLoop.CRun;

public class ACT_EXTSETEFFECTPARAM extends CAct
{
    public void execute(CRun rhPtr)
    {
        CObject pHo=rhPtr.rhEvtProg.get_ActionObjects(this);
        if (pHo==null)
            return;

        if((pHo.ros.rsEffect & GLRenderer.BOP_MASK) == GLRenderer.BOP_EFFECTEX)
        {
               String paramName = rhPtr.get_EventExpressionString((CParamExpression)evtParams[0]);
               CValue paramValue = rhPtr.get_EventExpressionAny((CParamExpression)evtParams[1]);

               if(pHo.hoEffect != null)
               {
                   boolean bModified = false;
                   int paramIndex = pHo.hoEffect.getParamIndex(paramName);
                   if(paramIndex != -1)
                   {
                        bModified = pHo.hoEffect.setParamValue(paramIndex, paramValue);
                   }
                   if(bModified)
                   {
                       pHo.roc.rcChanged = true;
                       if (pHo.roc.rcSprite != null) {
                           rhPtr.spriteGen.modifSpriteEffect(pHo.roc.rcSprite, pHo.ros.rsEffect, pHo.ros.rsEffectParam, pHo.ros.rsEffectShader);
                       }
                   }

               }
        }
    }
}
